import UIKit
import MBProgressHUD
import AVKit
import Photos
import MediaPlayer

class VideoEditorController: UIViewController{
    
    //MARK:- Booleans
    var keyTimeArray = NSMutableArray()
    var fromTransition = false;
    var fromFilter = false;
    var fromBgColor = false;
    var fromBgPattern = false;
    var fromBgGradient = false;
    var fromBgImage = false;
    var fromFastMusic = false;
    var fromSlowMusic = false;
    var fromNormalMusic = false;
    var fromTextAction = false;
    var isPlaying = false;
    var fromMusic = false;
    var imageDuration = 5.0
    var globalFilteredImgArray = [UIImage]()
    
    
    //MARK:- Variables and Constants
    var selectedIndex : Int = 0
    var globalAssetExporter : AVAssetExportSession!
    var globalRate : Float = 1.0
    var sizeLbl = 20
    var globalBackgroundImage = UIImage()
    var filterButtonArray : [UIButton] = Array(repeatElement(UIButton(), count: 8))
    var fromSave = false
    var fromPlayVideo = false
    var transitionButtonArray : [UIButton] = Array(repeatElement(UIButton(), count: 10))
    var globalFilterName : String?
    var globalrVideoComposition : AVVideoComposition?
    var globalVideoURL = NSURL()
    var globalAudioURL = NSURL()
    var  player = AVPlayer()
    var playerLayer  = AVPlayerLayer()
    var outputSize = CGSize(width: 640, height: 640)
    let imagesPerSecond: TimeInterval = 3 //each image will be stay for 3 secs
    var imageArrayToVideoURL = NSURL()
    let audioIsEnabled: Bool = false //if your video has no sound
    var asset: AVAsset!
    var selectedImageArray = [UIImage]()
    var globalSelectedTransitionTag = 0
    var audioPlayer: AVAudioPlayer?

    //MARK:- Constraints
    
    @IBOutlet weak var editToolViewBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var textToolBottomConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var backgrounViewTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var musicViewTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var speedTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var editViewTopConstraint: NSLayoutConstraint!
    
    //MARK:- IBOutlets
    
    
    @IBOutlet weak var fastBtnAction: UIButton!
    
    @IBOutlet weak var slowBtnAction: UIButton!
    
    
    @IBOutlet weak var transitionBtn: UIButton!
    
    
    @IBOutlet weak var musicBtn: UIButton!
    
    
    
    @IBOutlet weak var backgroundBtn: UIButton!
    
    @IBOutlet weak var speedBtn: UIButton!
    
    
    @IBOutlet weak var filterBtn: UIButton!
    
    
    @IBOutlet weak var speedSlider: UISlider!
    
    @IBOutlet weak var texthere: UILabel!
    
    @IBOutlet weak var txtfldfortxt: UITextField!
    @IBOutlet weak var textToolView: UIView!
    
    @IBOutlet weak var flipView: UIView!
    
    @IBOutlet weak var editToolView: UIView!
    
    
    @IBOutlet weak var musicCollectionView: UICollectionView!
    
    @IBOutlet weak var filterScrollView: UIScrollView!
    @IBOutlet weak var backgroundImageView: UIImageView!
    @IBOutlet weak var backgroundToolView: UIView!
    @IBOutlet weak var backgroundCollectionView: UICollectionView!
    
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var editView: UIView!
    @IBOutlet weak var musicView: UIView!
    @IBOutlet weak var speedView: UIView!
    @IBOutlet weak var optionsView: UIView!
    @IBOutlet weak var basciCollectionView: UICollectionView!
    @IBOutlet weak var toolContainerView: UIView!
    @IBOutlet weak var videoContainerView: UIView!
    @IBOutlet weak var playPauseBtn: UIButton!
    
    //MARK:- View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = false
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(saveTapped))
        playPauseBtn.isHidden = true
        fromTransition = true
        fromPlayVideo = true
        fromSave = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        DispatchQueue.main.async {
            self.basciCollectionView.reloadData()
        }
        setUpInitialView()
    }
    
    //MARK:- Custom Methods
    
    func filterScrollContents() {
        var xCoord: CGFloat = 5
        let yCoord: CGFloat = 10
        let buttonWidth:CGFloat = 60
        let gapBetweenButtons: CGFloat = 5
        for i in 0..<thumbnailArr.count{
            let filterButton = UIButton(type: .custom)
            filterButton.frame = CGRect(x: xCoord, y: yCoord, width: 60, height: 60)
            filterButton.tag = i
            filterButton.setImage(globalFilteredImgArray[i], for: .normal)
            filterButton.contentMode = UIViewContentMode.scaleAspectFit
            filterButton.addTarget(self, action:#selector(filterActionTapped), for: .touchUpInside)
            filterButton.layer.cornerRadius = 5
            filterButton.clipsToBounds = true
            xCoord +=  buttonWidth + gapBetweenButtons
            filterButtonArray.append(filterButton)
            filterScrollView.addSubview(filterButton)
        }
        filterScrollView.contentSize = CGSize(width: buttonWidth * CGFloat(thumbnailArr.count)+gapBetweenButtons+30.0, height: 60)
    }
    
    
    @objc func filterActionTapped(sender:UIButton){
        fromFilter = true
        fromTransition = false
        for eachButton in self.filterButtonArray {
            if eachButton.tag == sender.tag {
                eachButton.layer.borderColor = UIColor.darkGray.cgColor
                eachButton.layer.borderWidth = 3.0;
                
            } else {
                eachButton.layer.borderColor = UIColor.clear.cgColor
                eachButton.layer.borderWidth = 3.0;
                
            }
        }
        
        if(sender.tag==0){
            player.pause()
            self.isPlaying = false
            
            player.seek(to: kCMTimeZero)
            globalFilterName = "CISepiaTone"
            applyFilter(globalFilterToBeApplied: globalFilterName!)
        }else if(sender.tag==1){
            player.pause()
            self.isPlaying = false
            
            player.seek(to: kCMTimeZero)
            
            globalFilterName =  "CIPhotoEffectChrome"
            applyFilter(globalFilterToBeApplied: globalFilterName!)
            
        }else if(sender.tag==2){
            player.pause()
            self.isPlaying = false
            
            player.seek(to: kCMTimeZero)
            
            globalFilterName = "CIPhotoEffectTransfer"
            applyFilter(globalFilterToBeApplied: globalFilterName!)
            
            
        }else if(sender.tag==3){
            player.pause()
            self.isPlaying = false
            
            player.seek(to: kCMTimeZero)
            
            globalFilterName =  "CIPhotoEffectTonal"
            applyFilter(globalFilterToBeApplied: globalFilterName!)
            
            
        }else if(sender.tag==4){
            player.pause()
            self.isPlaying = false
            
            player.seek(to: kCMTimeZero)
            
            globalFilterName =  "CIPhotoEffectProcess"
            applyFilter(globalFilterToBeApplied: globalFilterName!)
            
            
        }else if(sender.tag==5){
            player.pause()
            self.isPlaying = false
            
            player.seek(to: kCMTimeZero)
            
            globalFilterName =  "CIPhotoEffectNoir"
            applyFilter(globalFilterToBeApplied: globalFilterName!)
            
        }else if(sender.tag==6){
            player.pause()
            self.isPlaying = false
            
            player.seek(to: kCMTimeZero)
            
            globalFilterName =  "CIPhotoEffectInstant"
            applyFilter(globalFilterToBeApplied: globalFilterName!)
        }
        else if(sender.tag==7){
            player.pause()
            self.isPlaying = false
            
            player.seek(to: kCMTimeZero)
            
            globalFilterName =  "CIPhotoEffectFade"
            applyFilter(globalFilterToBeApplied: globalFilterName!)
        }
    }
    
    func applyFilter(globalFilterToBeApplied:String){
        let filter = CIFilter(name: globalFilterToBeApplied)!
        let composition = AVVideoComposition(asset: asset, applyingCIFiltersWithHandler: { request in
            let source = request.sourceImage.clampedToExtent()
            filter.setValue(source, forKey: kCIInputImageKey)
            let output = filter.outputImage!.cropped(to: request.sourceImage.extent)
            request.finish(with: output, context: nil)
        })
        globalrVideoComposition = composition
        
    self.playVideoInPlayer(animatedVideoURL:self.globalVideoURL as URL, rowIndexPath: 0)
        
    }
    
    
    
    @objc func saveTapped(){
        let loadingNotification = MBProgressHUD.showAdded(to: view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.indeterminate
        loadingNotification.label.text = "Saving"
        self.fromPlayVideo = false
        self.fromSave = true
        if(fromFastMusic||fromNormalMusic||fromSlowMusic){
            saveVideosWithRateVariation()
        }else if(fromMusic){
         saveAudioTask()
        }
        else{
            exportVideoWithAnimation()
        }
    }
    
    
    func saveAudioTask(){
        
        // ===================+++++++=====================//
        
        
        let audioAsset = AVURLAsset(url: globalAudioURL as URL, options: nil)
        let videoAsset = AVURLAsset(url: self.globalVideoURL as URL, options: nil)
        
        let mixComposition = AVMutableComposition()
        
        let compositionCommentaryTrack: AVMutableCompositionTrack? = mixComposition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
        try? compositionCommentaryTrack?.insertTimeRange(CMTimeRangeMake(kCMTimeZero, videoAsset.duration), of: audioAsset.tracks(withMediaType: .audio)[0], at:kCMTimeZero)
        
        let compositionVideoTrack: AVMutableCompositionTrack? = mixComposition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid)
        try? compositionVideoTrack?.insertTimeRange(CMTimeRangeMake(kCMTimeZero, audioAsset.duration), of: videoAsset.tracks(withMediaType: .video)[0], at:kCMTimeZero)
        
        let _assetExport = AVAssetExportSession(asset: mixComposition, presetName: AVAssetExportPresetPassthrough)
        
        //  var savetUrl = URL(fileURLWithPath: savePath)
        let savePathUrl : NSURL = NSURL(fileURLWithPath: NSHomeDirectory() + "/Documents/EEnewVideo.mp4")
        self.removeFileAtURLIfExists(url: savePathUrl)
        _assetExport!.outputFileType = AVFileType("com.apple.quicktime-movie")
        
        
        _assetExport!.outputURL = savePathUrl as URL
        _assetExport!.shouldOptimizeForNetworkUse = true
        
        _assetExport!.exportAsynchronously(completionHandler: {
            
            if(_assetExport?.status == AVAssetExportSessionStatus.completed){
                
                print("fileSaved !",_assetExport?.outputURL!)
                PHPhotoLibrary.shared().performChanges({
                    PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: _assetExport?.outputURL! as! URL)
                    
                }) { saved, error in
                    DispatchQueue.main.async {
                        MBProgressHUD.hideAllHUDs(for: self.view, animated: true)
                    }
                    
                    if saved {
                        
                        let alertController = UIAlertController(title: "Video successfully saved", message: nil, preferredStyle: .alert)
                        let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                        alertController.addAction(defaultAction)
                        
                        print("The task is done,enjoy now!")
                        self.present(alertController, animated: true, completion: nil)
                    }else{
                        
                    }
                }
                DispatchQueue.main.async {
                    
                    self.playPauseBtn.isHidden = false
                    
                }
                
            }else{
                
                GlobalClass().showAlert(title:"", message: _assetExport?.error as! String, viewController:self)
            }
        })
    }
    
    
    
    
    
    
    func setUpInitialView(){
        addGestures()
        txtfldfortxt.delegate = self
        let loadingNotification = MBProgressHUD.showAdded(to: view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.indeterminate
        loadingNotification.label.text = "Your video is being prepared."
        
        buildVideoFromImageArray()
        
    }
    
    func addGestures(){
        
        let panGesture2 = UIPanGestureRecognizer(target: self, action: #selector(draggedView2(_:)))
        let pinchGesture2 = UIPinchGestureRecognizer(target: self, action: #selector(pinchedView2(sender:)))
        let rotate2 = UIRotationGestureRecognizer(target: self, action: #selector(rotateActionForImage2(sender:)))
        
        texthere.addGestureRecognizer(panGesture2)
        texthere.addGestureRecognizer(pinchGesture2)
        texthere.addGestureRecognizer(rotate2)
    }
    
    //MARK:- Gesture Actions
    
    
    @objc func pinchedView(sender:UIPinchGestureRecognizer){
        if let view = sender.view {
            view.transform = view.transform.scaledBy(x: sender.scale, y: sender.scale)
            sender.scale = 1
        }
    }
    
    @objc  func draggedView(_ panGesture:UIPanGestureRecognizer){
        let translation = panGesture.translation(in: view)
        panGesture.setTranslation(CGPoint.zero, in: view)
        let imgView = panGesture.view
        imgView?.center = CGPoint(x: (imgView?.center.x)!+translation.x, y: (imgView?.center.y)!+translation.y)
        imgView?.isMultipleTouchEnabled = true
        imgView?.isUserInteractionEnabled = true
    }
    
    @objc func rotateActionForImage(sender:UIRotationGestureRecognizer){
        let viewDrag = sender.view
        viewDrag?.transform=(viewDrag?.transform.rotated(by:sender.rotation))!
        sender.rotation=0
    }
    @objc func pinchedView2(sender:UIPinchGestureRecognizer){
        if let view = sender.view {
            view.transform = view.transform.scaledBy(x: sender.scale, y: sender.scale)
            sender.scale = 1
        }
    }
    
    @objc  func draggedView2(_ panGesture:UIPanGestureRecognizer){
        let translation = panGesture.translation(in: view)
        panGesture.setTranslation(CGPoint.zero, in: view)
        let imgView = panGesture.view
        imgView?.center = CGPoint(x: (imgView?.center.x)!+translation.x, y: (imgView?.center.y)!+translation.y)
        imgView?.isMultipleTouchEnabled = true
        imgView?.isUserInteractionEnabled = true
    }
    
    @objc func rotateActionForImage2(sender:UIRotationGestureRecognizer){
        let viewDrag = sender.view
        viewDrag?.transform=(viewDrag?.transform.rotated(by:sender.rotation))!
        sender.rotation=0
    }
    
    func buildVideoFromImageArray() {
        DispatchQueue.global(qos: .userInitiated).async {
            
            
            let videoName = String.init(format:"/Documents/%@.MP4",GlobalClass().randomString(length:4))
            
            self.imageArrayToVideoURL = NSURL(fileURLWithPath: NSHomeDirectory() + videoName)
            self.removeFileAtURLIfExists(url: self.imageArrayToVideoURL)
            guard let videoWriter = try? AVAssetWriter(outputURL: self.imageArrayToVideoURL as URL, fileType: AVFileType.mp4) else {
                fatalError("AVAssetWriter error")
            }
            let outputSettings = [AVVideoCodecKey : AVVideoCodecH264, AVVideoWidthKey : NSNumber(value: Float(self.outputSize.width)), AVVideoHeightKey : NSNumber(value: Float(self.outputSize.height))] as [String : Any]
            guard videoWriter.canApply(outputSettings: outputSettings, forMediaType: AVMediaType.video) else {
                fatalError("Negative : Can't apply the Output settings...")
            }
            let videoWriterInput = AVAssetWriterInput(mediaType: AVMediaType.video, outputSettings: outputSettings)
            let sourcePixelBufferAttributesDictionary = [kCVPixelBufferPixelFormatTypeKey as String : NSNumber(value: kCVPixelFormatType_32ARGB), kCVPixelBufferWidthKey as String: NSNumber(value: Float(self.outputSize.width)), kCVPixelBufferHeightKey as String: NSNumber(value: Float(self.outputSize.height))]
            let pixelBufferAdaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: videoWriterInput, sourcePixelBufferAttributes: sourcePixelBufferAttributesDictionary)
            if videoWriter.canAdd(videoWriterInput) {
                videoWriter.add(videoWriterInput)
            }
            if videoWriter.startWriting() {
                let zeroTime = CMTimeMake(Int64(self.imagesPerSecond),Int32(1))
                videoWriter.startSession(atSourceTime: zeroTime)
                
                assert(pixelBufferAdaptor.pixelBufferPool != nil)
                let media_queue = DispatchQueue(label: "mediaInputQueue")
                videoWriterInput.requestMediaDataWhenReady(on: media_queue, using: { () -> Void in
                    let fps: Int32 = 1
                    let framePerSecond: Int64 = Int64(self.imagesPerSecond)
                    let frameDuration = CMTimeMake(Int64(self.imagesPerSecond), fps)
                    var frameCount: Int64 = 0
                    var appendSucceeded = true
                    var newImageArr = self.selectedImageArray
                    while (!newImageArr.isEmpty) {
                        if (videoWriterInput.isReadyForMoreMediaData) {
                            let nextPhoto = newImageArr.remove(at: 0)
                            let lastFrameTime = CMTimeMake(frameCount * framePerSecond, fps)
                            let presentationTime = frameCount == 0 ? lastFrameTime : CMTimeAdd(lastFrameTime, frameDuration)
                            var pixelBuffer: CVPixelBuffer? = nil
                            let status: CVReturn = CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, pixelBufferAdaptor.pixelBufferPool!, &pixelBuffer)
                            if let pixelBuffer = pixelBuffer, status == 0 {
                                let managedPixelBuffer = pixelBuffer
                                CVPixelBufferLockBaseAddress(managedPixelBuffer, CVPixelBufferLockFlags(rawValue: CVOptionFlags(0)))
                                let data = CVPixelBufferGetBaseAddress(managedPixelBuffer)
                                let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
                                let context = CGContext(data: data, width: Int(self.outputSize.width), height: Int(self.outputSize.height), bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(managedPixelBuffer), space: rgbColorSpace, bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue)
                                context!.clear(CGRect(x: 0, y: 0, width: CGFloat(self.outputSize.width), height: CGFloat(self.outputSize.height)))
                                let horizontalRatio = CGFloat(self.outputSize.width) / nextPhoto.size.width
                                let verticalRatio = CGFloat(self.outputSize.height) / nextPhoto.size.height
                                //let aspectRatio = max(horizontalRatio, verticalRatio) // ScaleAspectFill
                                let aspectRatio = min(horizontalRatio, verticalRatio) // ScaleAspectFit
                                let newSize: CGSize = CGSize(width: nextPhoto.size.width * aspectRatio, height: nextPhoto.size.height * aspectRatio)
                                let x = newSize.width < self.outputSize.width ? (self.outputSize.width - newSize.width) / 2 : 0
                                let y = newSize.height < self.outputSize.height ? (self.outputSize.height - newSize.height) / 2 : 0
                                context?.draw(nextPhoto.cgImage!, in: CGRect(x: x, y: y, width: newSize.width, height: newSize.height))
                                CVPixelBufferUnlockBaseAddress(managedPixelBuffer, CVPixelBufferLockFlags(rawValue: CVOptionFlags(0)))
                                appendSucceeded = pixelBufferAdaptor.append(pixelBuffer, withPresentationTime: presentationTime)
                            } else {
                                print("Failed to allocate pixel buffer")
                                appendSucceeded = false
                            }
                        }
                        if !appendSucceeded {
                            break
                        }
                        frameCount += 1
                    }
                    videoWriterInput.markAsFinished()
                    videoWriter.finishWriting { () -> Void in
                        print("-----video1 url = \(self.imageArrayToVideoURL)")
                        self.globalVideoURL = self.imageArrayToVideoURL
                        
                        self.asset = AVAsset.init(url:self.imageArrayToVideoURL as URL)
                        DispatchQueue.main.async {
                            self.exportVideoWithAnimation()
                            
                        }
                    }
                })
            }
        }
    }
    
    func exportVideoWithAnimation() {
        let composition = AVMutableComposition()
        let track =  self.asset?.tracks(withMediaType: AVMediaType.video)
        let videoTrack:AVAssetTrack = track![0] as AVAssetTrack
        let timerange = CMTimeRangeMake(kCMTimeZero, (self.asset?.duration)!)
        let compositionVideoTrack:AVMutableCompositionTrack = composition.addMutableTrack(withMediaType: AVMediaType.video, preferredTrackID: CMPersistentTrackID())!
        
        do {
            try compositionVideoTrack.insertTimeRange(timerange, of: videoTrack, at: kCMTimeZero)
            compositionVideoTrack.preferredTransform = videoTrack.preferredTransform
        } catch {
            print(error)
        }
        
        //if your video has sound, you don’t need to check this
        if self.audioIsEnabled {
            let compositionAudioTrack:AVMutableCompositionTrack = composition.addMutableTrack(withMediaType: AVMediaType.audio, preferredTrackID: CMPersistentTrackID())!
            
            for audioTrack in (self.asset?.tracks(withMediaType: AVMediaType.audio))! {
                do {
                    try compositionAudioTrack.insertTimeRange(audioTrack.timeRange, of: audioTrack, at: kCMTimeZero)
                } catch {
                    print(error)
                }
            }
        }
        
        let size = videoTrack.naturalSize
        
        let videolayer = CALayer()
        videolayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        
        let parentlayer = CALayer()
        parentlayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        parentlayer.addSublayer(videolayer)
        //this is the animation part
        var time = [0.00001, 4, 9, 12, 16] //I used this
        var imgarray = self.selectedImageArray
        
        parentlayer.removeFromSuperlayer()
        
        
        
        for image in 0..<self.selectedImageArray.count {
            let nextPhoto = imgarray[image]
            
            let horizontalRatio = CGFloat(self.outputSize.width) / nextPhoto.size.width
            let verticalRatio = CGFloat(self.outputSize.height) / nextPhoto.size.height
            let aspectRatio = min(horizontalRatio, verticalRatio)
            let newSize: CGSize = CGSize(width: nextPhoto.size.width * aspectRatio, height: nextPhoto.size.height * aspectRatio)
            let x = newSize.width < self.outputSize.width ? (self.outputSize.width - newSize.width) / 2 : 0
            let y = newSize.height < self.outputSize.height ? (self.outputSize.height - newSize.height) / 2 : 0
            let blackLayer = CALayer()
            blackLayer.removeAllAnimations()
            //MARK:- Animations
            ///#1. left->right///
            if(self.globalSelectedTransitionTag == 0){
                blackLayer.frame = CGRect(x: 0, y: 0, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                blackLayer.backgroundColor = UIColor.clear.cgColor
                blackLayer.opacity = 0
                let imageLayer = CALayer()
                imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                imageLayer.contents = imgarray[image].cgImage
                blackLayer.addSublayer(imageLayer)
                
                
                let scaleAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
                if(image%2==0){
                    scaleAnimation.values = [0.9, 1.0, 0.9]
                }else{
                    scaleAnimation.values = [1.0, 0.9, 1.0]
                }
                scaleAnimation.beginTime = CFTimeInterval(time[image])
                scaleAnimation.duration = 10
                scaleAnimation.isRemovedOnCompletion = false
                blackLayer.add(scaleAnimation, forKey: "transform.scale")
                
                let fadeInOutAnimation = CABasicAnimation(keyPath: "opacity")
                fadeInOutAnimation.fromValue = 1
                fadeInOutAnimation.toValue = 0.6
                fadeInOutAnimation.duration = 10
                fadeInOutAnimation.beginTime = CFTimeInterval(time[image])
                fadeInOutAnimation.isRemovedOnCompletion = false
                blackLayer.add(fadeInOutAnimation, forKey: "opacity")
                
            }
                //2.right->left
            else if(self.globalSelectedTransitionTag == 1){
                if(image == 0 || image == 2 || image == 4){
                    blackLayer.frame = CGRect(x: 0, y: -videoTrack.naturalSize.height, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                    blackLayer.backgroundColor = UIColor.clear.cgColor
                    
                    let imageLayer = CALayer()
                    imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                    imageLayer.contents = imgarray[image].cgImage
                    blackLayer.addSublayer(imageLayer)
                    
                    let animation = CABasicAnimation()
                    animation.keyPath = "position.y"
                    animation.fromValue = videoTrack.naturalSize.height
                    animation.toValue = -2*videoTrack.naturalSize.height
                    animation.duration = 10
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeForwards
                    animation.isRemovedOnCompletion = false
                    // animation.speed = 0.7
                    
                    blackLayer.add(animation, forKey: "basic")
                }else{
                    
                    blackLayer.frame = CGRect(x: 0, y: -videoTrack.naturalSize.height, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                    blackLayer.backgroundColor = UIColor.clear.cgColor
                    
                    let imageLayer = CALayer()
                    imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                    imageLayer.contents = imgarray[image].cgImage
                    blackLayer.addSublayer(imageLayer)
                    
                    let animation = CABasicAnimation()
                    animation.keyPath = "position.y"
                    animation.fromValue = -videoTrack.naturalSize.height
                    animation.toValue =  2*videoTrack.naturalSize.height
                    animation.duration = 10
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeForwards
                    animation.isRemovedOnCompletion = false
                    blackLayer.add(animation, forKey: "basic")
                }
            }else if(self.globalSelectedTransitionTag == 2){
                // #4. bottom->top
                
                blackLayer.frame = CGRect(x: 0, y: -videoTrack.naturalSize.height, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                blackLayer.backgroundColor = UIColor.clear.cgColor
                
                let imageLayer = CALayer()
                imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                imageLayer.contents = imgarray[image].cgImage
                blackLayer.addSublayer(imageLayer)
                if(image%2 == 0 ){
                    let animation = CABasicAnimation()
                    animation.keyPath = "position"
                    
                    animation.fromValue = [200, 200]
                    animation.toValue = [2200, 2200]
                    animation.duration = 5
                    print("CACurrentMediaTime()",CACurrentMediaTime())
                    animation.beginTime = CFTimeInterval(time[image]); //CACurrentMediaTime() + 5.0;
                    animation.fillMode = kCAFillModeForwards
                    animation.isRemovedOnCompletion = false
                    blackLayer.add(animation, forKey: "basic")
                    
                }else{
                    let animation = CABasicAnimation()
                    animation.keyPath = "position.y"
                    animation.fromValue = 2 * videoTrack.naturalSize.height
                    animation.toValue = -videoTrack.naturalSize.height
                    animation.duration = 5
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeForwards
                    animation.isRemovedOnCompletion = false
                    //   animation.speed = 0.7
                    blackLayer.add(animation, forKey: "basic")
                    
                    let fadeOutAnimation = CABasicAnimation(keyPath: "opacity")
                    fadeOutAnimation.fromValue = 1
                    fadeOutAnimation.toValue = 0
                    fadeOutAnimation.duration = 10
                    fadeOutAnimation.beginTime = CACurrentMediaTime() + 0.3;
                    fadeOutAnimation.isRemovedOnCompletion = false
                    //fadeOutAnimation.speed = 0.7
                    
                    blackLayer.add(fadeOutAnimation, forKey: "opacity")
                    
                }
                
                
                
            }else if(self.globalSelectedTransitionTag == 3){
                
                ///#5. opacity(1->0)(left->right)///
                
                blackLayer.frame = CGRect(x: -videoTrack.naturalSize.width, y: 0, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                blackLayer.backgroundColor = UIColor.clear.cgColor
                
                let imageLayer = CALayer()
                imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                imageLayer.contents = imgarray[image].cgImage
                blackLayer.addSublayer(imageLayer)
                
                let animation = CABasicAnimation()
                animation.keyPath = "position.x"
                animation.fromValue = -videoTrack.naturalSize.width
                animation.toValue = 2 * (videoTrack.naturalSize.width)
                animation.duration = 3
                animation.beginTime = CFTimeInterval(time[image])
                //  animation.speed = 0.7
                
                animation.fillMode = kCAFillModeForwards
                animation.isRemovedOnCompletion = false
                blackLayer.add(animation, forKey: "basic")
                
                let fadeOutAnimation = CABasicAnimation(keyPath: "opacity")
                fadeOutAnimation.fromValue = 1
                fadeOutAnimation.toValue = 0
                fadeOutAnimation.duration = 5
                fadeOutAnimation.beginTime = CFTimeInterval(time[image])
                fadeOutAnimation.isRemovedOnCompletion = false
                // fadeOutAnimation.speed = 0.7
                
                blackLayer.add(fadeOutAnimation, forKey: "opacity")
            }
            else if(self.globalSelectedTransitionTag == 4){
                blackLayer.frame = CGRect(x: 2 * videoTrack.naturalSize.width, y: 0, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                blackLayer.backgroundColor = UIColor.clear.cgColor
                
                let imageLayer = CALayer()
                imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                imageLayer.contents = imgarray[image].cgImage
                blackLayer.addSublayer(imageLayer)
                
                let animation = CABasicAnimation()
                animation.keyPath = "position.x"
                animation.fromValue = 2 * videoTrack.naturalSize.width
                animation.toValue = -videoTrack.naturalSize.width
                animation.duration = 5
                animation.beginTime = CFTimeInterval(time[image])
                animation.fillMode = kCAFillModeForwards
                animation.isRemovedOnCompletion = false
                blackLayer.add(animation, forKey: "basic")
                
                let fadeOutAnimation = CABasicAnimation(keyPath: "opacity")
                fadeOutAnimation.fromValue = 1
                fadeOutAnimation.toValue = 0
                fadeOutAnimation.duration = 15
                fadeOutAnimation.beginTime = CFTimeInterval(time[image])
                fadeOutAnimation.isRemovedOnCompletion = false
                
                blackLayer.add(fadeOutAnimation, forKey: "opacity")
            }else if(self.globalSelectedTransitionTag == 5){
                ///#7. opacity(1->0)(top->bottom)///
                
                blackLayer.frame = CGRect(x: 0, y: 2 * videoTrack.naturalSize.height, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                blackLayer.backgroundColor = UIColor.clear.cgColor
                
                let imageLayer = CALayer()
                imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                imageLayer.contents = imgarray[image].cgImage
                blackLayer.addSublayer(imageLayer)
                
                let animation = CABasicAnimation()
                animation.keyPath = "position.y"
                animation.fromValue = 2 * videoTrack.naturalSize.height
                animation.toValue = -videoTrack.naturalSize.height
                animation.duration = 3
                animation.beginTime = CFTimeInterval(time[image])
                animation.fillMode = kCAFillModeForwards
                animation.isRemovedOnCompletion = false
                //   animation.speed = 0.7
                blackLayer.add(animation, forKey: "basic")
                
                let fadeOutAnimation = CABasicAnimation(keyPath: "opacity")
                fadeOutAnimation.fromValue = 1
                fadeOutAnimation.toValue = 0
                fadeOutAnimation.duration = 3
                fadeOutAnimation.beginTime = CFTimeInterval(time[image])
                fadeOutAnimation.isRemovedOnCompletion = false
                //fadeOutAnimation.speed = 0.7
                
                blackLayer.add(fadeOutAnimation, forKey: "opacity")
            }
            else if(self.globalSelectedTransitionTag == 6){
                //#10. scale(big->small->big)///
                if(image == 0){
                    blackLayer.frame = CGRect(x: 0, y:0, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                    blackLayer.backgroundColor = UIColor.clear.cgColor
                    
                    let imageLayer = CALayer()
                    imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                    imageLayer.contents = imgarray[image].cgImage
                    blackLayer.addSublayer(imageLayer)
                    
                    let rotationAnimation = CAKeyframeAnimation(keyPath: "transform.rotation")
                    rotationAnimation.keyTimes = [0,1]
                    rotationAnimation.values = [0, M_PI]
                    rotationAnimation.duration = 5
                    rotationAnimation.beginTime = CFTimeInterval(time[image])
                    rotationAnimation.repeatCount = 1
                    blackLayer.add(rotationAnimation, forKey: nil)
                    
                }
                    
                    
                else if(image == 1){
                    blackLayer.frame = CGRect(x: 0, y: -videoTrack.naturalSize.height, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                    blackLayer.backgroundColor = UIColor.clear.cgColor
                    
                    let imageLayer = CALayer()
                    imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                    imageLayer.contents = imgarray[image].cgImage
                    blackLayer.addSublayer(imageLayer)
                    
                    let animation = CABasicAnimation()
                    animation.keyPath = "position.y"
                    animation.fromValue = -videoTrack.naturalSize.height
                    animation.toValue = 2 * videoTrack.naturalSize.height
                    animation.duration = 3
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeForwards
                    animation.isRemovedOnCompletion = false
                    blackLayer.add(animation, forKey: "basic")
                    
                    let fadeOutAnimation = CABasicAnimation(keyPath: "opacity")
                    fadeOutAnimation.fromValue = 1
                    fadeOutAnimation.toValue = 0
                    fadeOutAnimation.duration = 3
                    fadeOutAnimation.beginTime = CFTimeInterval(time[image])
                    fadeOutAnimation.isRemovedOnCompletion = false
                    blackLayer.add(fadeOutAnimation, forKey: "opacity")
                }else if(image == 2){
                    blackLayer.frame = CGRect(x: 0, y: 0, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                    blackLayer.backgroundColor = UIColor.clear.cgColor
                    blackLayer.opacity = 0
                    
                    let imageLayer = CALayer()
                    imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                    imageLayer.contents = imgarray[image].cgImage
                    blackLayer.addSublayer(imageLayer)
                    
                    let scaleAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
                    scaleAnimation.values = [1, 0, 1]
                    scaleAnimation.beginTime = CFTimeInterval(time[image])
                    scaleAnimation.duration = 3
                    scaleAnimation.isRemovedOnCompletion = false
                    blackLayer.add(scaleAnimation, forKey: "transform.scale")
                    
                    let fadeOutAnimation = CABasicAnimation(keyPath: "opacity")
                    fadeOutAnimation.fromValue = 1
                    fadeOutAnimation.toValue = 1
                    fadeOutAnimation.duration = 3
                    fadeOutAnimation.beginTime = CFTimeInterval(time[image])
                    fadeOutAnimation.isRemovedOnCompletion = false
                    blackLayer.add(fadeOutAnimation, forKey: "opacity")
                }else if(image == 3){
                    
                    blackLayer.frame = CGRect(x: 0, y: -videoTrack.naturalSize.height, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                    blackLayer.backgroundColor = UIColor.clear.cgColor
                    
                    let imageLayer = CALayer()
                    imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                    imageLayer.contents = imgarray[image].cgImage
                    blackLayer.addSublayer(imageLayer)
                    
                    let animation = CABasicAnimation()
                    animation.keyPath = "position.y"
                    animation.fromValue = -videoTrack.naturalSize.height
                    animation.toValue = 2 * videoTrack.naturalSize.height
                    animation.duration = 3
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeForwards
                    animation.isRemovedOnCompletion = false
                    blackLayer.add(animation, forKey: "basic")
                    
                    let fadeOutAnimation = CABasicAnimation(keyPath: "opacity")
                    fadeOutAnimation.fromValue = 1
                    fadeOutAnimation.toValue = 0
                    fadeOutAnimation.duration = 3
                    fadeOutAnimation.beginTime = CFTimeInterval(time[image])
                    fadeOutAnimation.isRemovedOnCompletion = false
                    blackLayer.add(fadeOutAnimation, forKey: "opacity")
                }
            }else if(self.globalSelectedTransitionTag == 7){
                
                if(image == 0){
                    
                    blackLayer.frame = CGRect(x: -videoTrack.naturalSize.width, y: 0, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                    blackLayer.backgroundColor = UIColor.clear.cgColor
                    
                    
                    let imageLayer = CALayer()
                    imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                    imageLayer.contents = imgarray[image].cgImage
                    blackLayer.addSublayer(imageLayer)
                    
                    let animation = CABasicAnimation()
                    animation.keyPath = "position.x"
                    animation.fromValue = -videoTrack.naturalSize.width
                    animation.toValue = 5 * (videoTrack.naturalSize.width)
                    animation.duration = 10
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeBoth
                    animation.isRemovedOnCompletion = true
                    
                    //imageLayer.opacity = 0.5
                    blackLayer.add(animation, forKey: "opacity")
                    
                }else if(image == 1){
                    blackLayer.frame = CGRect(x: 2 * videoTrack.naturalSize.width, y: 0, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                    blackLayer.backgroundColor = UIColor.clear.cgColor
                    
                    let imageLayer = CALayer()
                    imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                    imageLayer.contents = imgarray[image].cgImage
                    blackLayer.addSublayer(imageLayer)
                    
                    let animation = CABasicAnimation()
                    animation.keyPath = "position.x"
                    animation.fromValue = 2 * (videoTrack.naturalSize.width)
                    animation.toValue = -videoTrack.naturalSize.width
                    animation.duration = 10
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeForwards
                    animation.isRemovedOnCompletion = true
                    // animation.speed = 0.7
                    blackLayer.add(animation, forKey: "basic")
                }else if(image == 2){
                    blackLayer.frame = CGRect(x: 0, y: 2 * videoTrack.naturalSize.height, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                    blackLayer.backgroundColor = UIColor.clear.cgColor
                    
                    let imageLayer = CALayer()
                    imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                    imageLayer.contents = imgarray[image].cgImage
                    blackLayer.addSublayer(imageLayer)
                    
                    let animation = CABasicAnimation()
                    animation.keyPath = "position.y"
                    animation.fromValue = 2 * videoTrack.naturalSize.height
                    animation.toValue = -videoTrack.naturalSize.height
                    animation.duration = 8
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeForwards
                    animation.isRemovedOnCompletion = true
                    
                    blackLayer.add(animation, forKey: "basic")
                }else if(image == 3){
                    blackLayer.frame = CGRect(x: 0, y: videoTrack.naturalSize.height, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                    blackLayer.backgroundColor = UIColor.clear.cgColor
                    
                    let imageLayer = CALayer()
                    imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                    imageLayer.contents = imgarray[image].cgImage
                    blackLayer.addSublayer(imageLayer)
                    
                    let animation = CABasicAnimation()
                    animation.keyPath = "position.y"
                    animation.fromValue = -videoTrack.naturalSize.height
                    
                    animation.toValue = 2*videoTrack.naturalSize.height
                    animation.duration = 14
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeForwards
                    animation.isRemovedOnCompletion = true
                    // animation.speed = 0.7
                    blackLayer.add(animation, forKey: "basic")
                }
                else if(image == 4){
                    blackLayer.frame = CGRect(x: 0, y:2*videoTrack.naturalSize.height, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                    blackLayer.backgroundColor = UIColor.clear.cgColor
                    
                    let imageLayer = CALayer()
                    imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                    imageLayer.contents = imgarray[image].cgImage
                    blackLayer.addSublayer(imageLayer)
                    
                    let animation = CABasicAnimation()
                    animation.keyPath = "position.y"
                    animation.fromValue = -videoTrack.naturalSize.height
                    
                    animation.toValue =  2 * videoTrack.naturalSize.height
                    
                    animation.duration = 14
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeForwards
                    animation.isRemovedOnCompletion = true
                    blackLayer.add(animation, forKey: "basic")
                    
                }
            }
                
                
            else{
                
                
                blackLayer.frame = CGRect(x: 0, y: 0, width: videoTrack.naturalSize.width, height: videoTrack.naturalSize.height)
                blackLayer.backgroundColor = UIColor.clear.cgColor
                
                let imageLayer = CALayer()
                imageLayer.frame = CGRect(x: x, y: y, width: newSize.width, height: newSize.height)
                imageLayer.contents = imgarray[image].cgImage
                blackLayer.addSublayer(imageLayer)
                
                if(image%2 == 0 ){
                    let animation = CABasicAnimation(keyPath: "transform.scale.x")
                    animation.fromValue = 1
                    animation.toValue = 2
                    animation.duration = 5
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeForwards
                    animation.repeatCount = 1
                    blackLayer.add(animation, forKey: nil)
                    
                }else{
                    let animation = CABasicAnimation(keyPath: "opacity")
                    animation.fromValue = 0
                    animation.toValue = 1
                    animation.duration = 5
                    animation.beginTime = CFTimeInterval(time[image])
                    animation.fillMode = kCAFillModeForwards
                    animation.repeatCount = 1
                    blackLayer.add(animation, forKey: nil)
                    
                }
                
            }
            
            
            
            parentlayer.addSublayer(blackLayer)
        }
        
        
        
        DispatchQueue.global().async {
            
            let layercomposition = AVMutableVideoComposition()
            layercomposition.frameDuration = CMTimeMake(1, 30)
            layercomposition.renderSize = size
            
            if(self.fromBgImage||self.fromBgPattern||self.fromBgGradient||self.fromBgColor){
                  layercomposition.animationTool = AVVideoCompositionCoreAnimationTool(postProcessingAsVideoLayer: videolayer, in: parentlayer)
                
                self.applyVideoEffects(to:layercomposition, size:size, andImage:self.globalBackgroundImage, andController:self, andsourceOverlay:"fromBgImage")
                
                
                
            }else if(self.fromTextAction){
                self.applyVideoEffects(to:layercomposition, size: size)
            }
                
                
            else{
                layercomposition.animationTool = AVVideoCompositionCoreAnimationTool(postProcessingAsVideoLayer: videolayer, in: parentlayer)
            }
            
            let instruction = AVMutableVideoCompositionInstruction()
            instruction.timeRange = CMTimeRangeMake(kCMTimeZero, composition.duration)
            let videotrack = composition.tracks(withMediaType: AVMediaType.video)[0] as AVAssetTrack
            let layerinstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: videotrack)
            instruction.layerInstructions = [layerinstruction]
            layercomposition.instructions = [instruction]
            if(self.fromTransition){
                self.globalrVideoComposition = layercomposition
            }
            
            
            let videoName2 = String.init(format:"/Documents/%@.MP4",GlobalClass().randomString(length:4))
            let animatedVideoURL = NSURL(fileURLWithPath:NSHomeDirectory() + videoName2)
            self.removeFileAtURLIfExists(url: animatedVideoURL)
            
            
            
            
            // AVAssetExportPresetHighestQuality
            guard let assetExport = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else {return}
            assetExport.videoComposition = self.globalrVideoComposition
            
            
            self.playVideoInPlayer(animatedVideoURL: animatedVideoURL as URL, rowIndexPath: 0)
            
            
            assetExport.outputFileType = AVFileType.mp4
            assetExport.outputURL = animatedVideoURL as URL
            print("****** animatedVideoURL *****",animatedVideoURL)
            assetExport.exportAsynchronously(completionHandler: {
                switch assetExport.status{
                case  AVAssetExportSessionStatus.failed:
                    
                    let errormsg = (String(describing: assetExport.error))
                    let alertController = UIAlertController(title:"Error", message:errormsg, preferredStyle: .alert)
                    let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(defaultAction)
                    self.present(alertController, animated: true, completion: nil)
                     MBProgressHUD.hideAllHUDs(for: self.view, animated: true)
                    print("errormsg",errormsg)
                    
                case AVAssetExportSessionStatus.cancelled:
                    print("cancelled \(String(describing: assetExport.error))")
                    let alertController = UIAlertController(title:"Cancelled", message: (assetExport.error as! String), preferredStyle: .alert)
                    let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(defaultAction)
                     MBProgressHUD.hideAllHUDs(for: self.view, animated: true)
                    
                    print("The task is done,enjoy now!")
                    self.present(alertController, animated: true, completion: nil)
                    
                    
                default:
                    print("Exported")
                    
                    if(self.fromPlayVideo){
                        DispatchQueue.main.async {
                            
                            self.globalVideoURL = animatedVideoURL;
                            self.playVideoInPlayer(animatedVideoURL: self.globalVideoURL as URL, rowIndexPath: 0)
                        }
                    }else if(self.fromSave){
                        
                        PHPhotoLibrary.shared().performChanges({
                            PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: animatedVideoURL as URL)
                            print("222222 animatedVideoURL",animatedVideoURL)
                            
                            
                            
                        }) { saved, error in
                            DispatchQueue.main.async {
                                MBProgressHUD.hideAllHUDs(for: self.view, animated: true)
                            }
                            
                            if saved {
                                
                                let alertController = UIAlertController(title: "Video successfully saved", message: nil, preferredStyle: .alert)
                                let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                                alertController.addAction(defaultAction)
                                
                                print("The task is done,enjoy now!")
                                self.present(alertController, animated: true, completion: nil)
                            }else{
                                
                            }
                        }
                    }
                }
            })
        }
    }
    
    
    
    func saveVideosWithRateVariation(){
        let videoAsset = AVAsset(url: self.globalVideoURL as URL) as AVAsset
        
        let composition = AVMutableComposition()
        let videoCompositions = composition.addMutableTrack(withMediaType: AVMediaType.video, preferredTrackID: CMPersistentTrackID())
        do {
            try videoCompositions?.insertTimeRange(CMTimeRangeMake(kCMTimeZero, videoAsset.duration), of: (videoAsset.tracks(withMediaType: AVMediaType.video).first)!, at: kCMTimeZero)
        } catch {
            print("handle insert error")
            return
        }
        let videoDuration = videoAsset.duration
        let finalTimeScale:Int64 = (Int64(float_t(videoDuration.value) / globalRate))
        print("player rate is",globalRate)
        videoCompositions?.scaleTimeRange(CMTimeRangeMake(kCMTimeZero, videoDuration), toDuration: CMTimeMake(finalTimeScale, videoDuration.timescale))
        let fileManager = FileManager.default
        let documentDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        var outputURL = documentDirectory.appendingPathComponent("output")
        do {
            
            try fileManager.createDirectory(at: outputURL, withIntermediateDirectories: true, attributes: nil)
            outputURL = outputURL.appendingPathComponent("\ratedVideo.mp4")
        }catch let error {
            print(error)
        }
        try? fileManager.removeItem(at: outputURL)
        
        guard let exporter = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else { return }
        exporter.outputURL = outputURL
        exporter.outputFileType = .mp4
        exporter.exportAsynchronously {
            switch exporter.status {
            case .completed:
                print("exported at #####*** \(outputURL)")
                UISaveVideoAtPathToSavedPhotosAlbum(outputURL.path,self, #selector(self.image(_:didFinishSavingWithError:contextInfo:)), nil)
            case .failed:
                print("failed \(exporter.error.debugDescription)")
            case .cancelled:
                print("cancelled \(exporter.error.debugDescription)")
            default: break
            }
        }
    }
    
    
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        
        if error == nil {
            let ac = UIAlertController(title: "Saved!", message: "Video saved to your photos.", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(ac, animated: true, completion: nil)
           
            
        } else {
            let ac = UIAlertController(title: "Save error", message: error?.localizedDescription, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(ac, animated: true, completion: nil)
        }
         MBProgressHUD.hideAllHUDs(for:self.view, animated: true)
    }
    
    
    
    
    func playVideoInPlayer(animatedVideoURL:URL,rowIndexPath:Int){
        //if(globalFilterName != nil){
            self.asset = AVAsset.init(url: self.globalVideoURL  as URL)
            let newPlayerItem = AVPlayerItem.init(asset:self.asset);
            newPlayerItem.videoComposition=globalrVideoComposition
            self.player = AVPlayer.init(playerItem:newPlayerItem)
//        }else{
//            let newPlayerItem = AVPlayerItem.init(url:animatedVideoURL )
//            self.player = AVPlayer.init(playerItem:newPlayerItem)
//            if(fromMusic){
//                let audioUrl = Bundle.main.url(forResource:musicLabelArray[rowIndexPath], withExtension: "mp3")
//                self.globalAudioURL = audioUrl as! NSURL
//                self.playAudio(url:audioUrl!)
//            }
//
//        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.finishedPlaying(_:)), name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object:nil)
        self.playerLayer = AVPlayerLayer.init(player:self.player)
        let width: CGFloat = self.videoContainerView.frame.size.width
        let height: CGFloat = self.videoContainerView.frame.size.height
        self.playerLayer.frame = CGRect(x: 0.0, y:0, width: width, height: height)
        self.playerLayer.backgroundColor = UIColor.clear.cgColor
        self.playerLayer.videoGravity = .resizeAspectFill
        
        
        self.playerLayer.removeFromSuperlayer()
        self.videoContainerView.layer.addSublayer( self.playerLayer)
        self.playPauseBtn.isHidden = false
        
        self.playPauseBtn.setImage(UIImage.init(named:"pause"), for:.normal)
        
        DispatchQueue.main.async {
            MBProgressHUD.hideAllHUDs(for:self.view, animated:true)
            self.player.play()
            self.isPlaying = true
        }
    }
    
    @objc func finishedPlaying( _ myNotification:NSNotification) {
        self.playPauseBtn.isHidden = false
        isPlaying = false
        player.seek(to: kCMTimeZero)
        playPauseBtn.setImage(UIImage.init(named:"play"), for:.normal)
        audioPlayer?.pause()
    }
    
    
    
    func removeFileAtURLIfExists(url: NSURL) {
        if let filePath = url.path {
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: filePath) {
                do{
                    try fileManager.removeItem(atPath: filePath)
                } catch let error as NSError {
                    print("Couldn't remove existing destination file: \(error)")
                }
            }
        }
    }
    
    func applyVideoEffects(to composition: AVMutableVideoComposition?, size: CGSize, andImage overlayImage: UIImage?, andController VC: UIViewController?, andsourceOverlay overalyStr: String?) {
        print("overlayImage \(size.width) \(size.height)")
        
        // 1 - set up the overlay
        let overlayLayer = CALayer()
        overlayLayer.contents = overlayImage?.cgImage
        if (overalyStr == "Frame") {
            overlayLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.width)
        } else {
            overlayLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        }
        overlayLayer.masksToBounds = true
        
        // 2 - set up the parent layer
        let parentLayer = CALayer()
        let videoLayer = CALayer()
        parentLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        videoLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        parentLayer.addSublayer(videoLayer)
        parentLayer.addSublayer(overlayLayer)
        // 3 - apply magic
    composition!.animationTool = AVVideoCompositionCoreAnimationTool(postProcessingAsVideoLayer: videoLayer, in: parentLayer)
        
        
        
        
    }
    
    //MARK:- Down Actions
    
    @IBAction func backgroundDownAction(_ sender: Any) {
        
        
        
        if(fromBgColor){
            self.backgroundCollectionView.isHidden = true
            self.backgroundToolView.isHidden = false
        }else if(fromBgPattern){
            self.backgroundCollectionView.isHidden = true
            self.backgroundToolView.isHidden = false
        }else if(fromBgGradient){
            self.backgroundCollectionView.isHidden = true
            self.backgroundToolView.isHidden = false
        }else if(fromBgImage){
            self.backgroundCollectionView.isHidden = true
            self.backgroundToolView.isHidden = false
        }
        else{
            UIView.animate(withDuration:0.5, animations: {
                self.editViewTopConstraint.constant = 50
                self.speedTopConstraint.constant = 50
                self.musicViewTopConstraint.constant = 50
                self.backgrounViewTopConstraint.constant = 50
                self.view.layoutIfNeeded()
            }, completion:nil)
        }
    }
    
    @IBAction func textDoneAction(_ sender: UIButton) {
        texthere.text = txtfldfortxt.text
        fromTextAction = true;
    }
    
    
    @IBAction func editViewDownAction(_ sender: UIButton){
        UIView.animate(withDuration:0.5, animations: {
            self.editToolViewBottomConstraint.constant = -260;
            self.view.layoutIfNeeded()
        }, completion: nil)
        //        self.editToolView.isHidden = false
        //        self.filterScrollView.isHidden = false
        //self.filterScrollContents()
    }
    
    
    
    @IBAction func textToolViewDownAction(_ sender: UIButton) {
        self.texthere.isHidden = false
        UIView.animate(withDuration:0.5) {
            self.textToolBottomConstraint.constant = 250
            self.view.layoutIfNeeded()
        }
    }
    
    
    func applyVideoEffects(to composition: AVMutableVideoComposition?, size: CGSize) {
        // 1 - Set up the text layer
        let subtitle1Text = CATextLayer()
        subtitle1Text.frame = texthere.frame
        subtitle1Text.string = texthere.text
        subtitle1Text.font = texthere.font
        subtitle1Text.fontSize = CGFloat(sizeLbl)
        subtitle1Text.alignmentMode = kCAAlignmentCenter
        subtitle1Text.foregroundColor = texthere.textColor.cgColor
        
        
        
        let parentLayer = CALayer()
        let videoLayer = CALayer()
        parentLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        
        //the main part of video where video is actually played
        
        videoLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        
        
        // 2 - The usual overlay
        let overlayLayer = CALayer()
        overlayLayer.addSublayer(subtitle1Text)
        overlayLayer.frame = CGRect(x:0, y: 0, width: size.width, height: size.height)
        print("the value of overlaylayer is %@",overlayLayer.frame )
        overlayLayer.masksToBounds = true
        
        
        //
        parentLayer.addSublayer(videoLayer)
        parentLayer.addSublayer(overlayLayer)
        
        composition!.animationTool = AVVideoCompositionCoreAnimationTool(postProcessingAsVideoLayer: videoLayer, in: parentLayer)
    }
    
    
    //MARK:- Button's Action
    
    @IBAction func speedSliderAction(_ sender: UISlider){
        playPauseBtn.isHidden = true
        globalRate = sender.value
        player.rate = globalRate
        
    }
    
    
    
    
    //==========MARK:- flip actions ==================
    @IBAction func verticalFlipAction(_ sender: UIButton) {
    
        
    }
    
    
    @IBAction func rotateAction(_ sender: UIButton) {
    }
    
    
    @IBAction func horizontalFlipAction(_ sender: UIButton) {
    }
    
    //==========MARK:- flip actions ==================
    
    
    @IBAction func flipAction(_ sender: Any) {
        self.editToolView.isHidden = false
        self.flipView.isHidden = false
        self.filterScrollView.isHidden = true
        
    }
    
    
    
    @IBAction func textToolAction(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5) {
            self.texthere.isHidden = false
            self.textToolBottomConstraint.constant = -320
            self.fromTextAction = true;
            self.view.layoutIfNeeded()
        }
    }
    
    
    
    
    @IBAction func fastMusicAction(_ sender: UIButton) {
        fastBtnAction.setImage(UIImage.init(named:"fast1"), for: UIControlState.normal)
        slowBtnAction.setImage(UIImage.init(named:"slow"), for: UIControlState.normal)

        
        self.playPauseBtn.isHidden = true
        isPlaying = true
        player.seek(to: kCMTimeZero)

        playPauseBtn.setImage(UIImage.init(named:"play"), for:.normal)
        
        fromSlowMusic = false;
        fromNormalMusic = false;
        fromFastMusic = true;
        speedSlider.minimumValue = 1.0
        speedSlider.value = 0.0
        speedSlider.maximumValue = 2.5
        globalRate = 1.0
        player.rate = globalRate
    }
    
    
    @IBAction func normalMusicAction(_ sender: UIButton) {
        fromFastMusic = false;
        fromSlowMusic = false;
        fromNormalMusic = true;
        player.rate = globalRate
    }
    
    
    @IBAction func slowMusicAction(_ sender: UIButton) {
        self.playPauseBtn.isHidden = true
//        isPlaying = true
//        player.seek(to: kCMTimeZero)
       //  player.pause()
      //  playPauseBtn.setImage(UIImage.init(named:"play"), for:.normal)

        fastBtnAction.setImage(UIImage.init(named:"fast"), for: UIControlState.normal)
        slowBtnAction.setImage(UIImage.init(named:"slow1"), for: UIControlState.normal)
        
        
        
        
        fromFastMusic = false;
        fromNormalMusic = false;
        fromSlowMusic = true;
        speedSlider.minimumValue =  0.2
        speedSlider.value = 1.0
        speedSlider.maximumValue = 1.0
        globalRate = 1.0

        player.rate = globalRate
        
    }
    
    
    
    @IBAction func filterBtnAction(_ sender: UIButton) {
        globalFilteredImgArray=GlobalClass().addFilter()

        
        backgroundBtn.setImage(UIImage.init(named:"bg"), for: UIControlState.normal);
        transitionBtn.setImage(UIImage.init(named:"transition"), for: UIControlState.normal)
        musicBtn.setImage(UIImage.init(named:"music"), for: UIControlState.normal)
        
        speedBtn.setImage(UIImage.init(named:"speed"), for: UIControlState.normal)
        
        
        filterBtn.setImage(UIImage.init(named:"filter1"), for: UIControlState.normal)
        
        UIView.animate(withDuration:0.5, animations: {
            self.editToolViewBottomConstraint.constant = -160;
            self.view.layoutIfNeeded()
        }, completion: nil)
        self.editToolView.isHidden = false
        self.filterScrollView.isHidden = false
        self.filterScrollContents()
    }
    
    
    
    
    @IBAction func colorAction(_ sender: UIButton) {
        fromBgColor = true
        fromBgPattern = false
        fromBgGradient = false
        
        backgroundToolView.isHidden = true
        backgroundCollectionView.isHidden = false;
        backgroundCollectionView.reloadData()
    }
    
    
    @IBAction func patternAction(_ sender: UIButton) {
        fromBgPattern = true
        fromBgColor = false
        fromBgGradient = false
        
        backgroundToolView.isHidden = true
        backgroundCollectionView.isHidden = false;
        backgroundCollectionView.reloadData()
    }
    
    
    @IBAction func gradientAAction(_ sender: UIButton) {
        fromBgPattern = false
        fromBgColor = false
        fromBgGradient = true
        fromBgImage = false
        
        backgroundToolView.isHidden = true
        backgroundCollectionView.isHidden = false;
        backgroundCollectionView.reloadData()
    }
    
    
    @IBAction func imagesAction(_ sender: UIButton) {
        fromBgPattern = false
        fromBgColor = false
        fromBgGradient = false
        fromBgImage = true
        
        backgroundToolView.isHidden = true
        backgroundCollectionView.isHidden = false;
        backgroundCollectionView.reloadData()
    }
    
    @IBAction func effectsAction(_ sender: UIButton) {
        transitionBtn.setImage(UIImage.init(named:"transition1"), for: UIControlState.normal)
        musicBtn.setImage(UIImage.init(named:"music"), for: UIControlState.normal)
        
        speedBtn.setImage(UIImage.init(named:"speed"), for: UIControlState.normal)
        backgroundBtn.setImage(UIImage.init(named:"bg"), for: UIControlState.normal)
        
        
        
        fromTransition = true
        fromFilter = false
        UIView.animate(withDuration:0.5, animations: {
            self.editViewTopConstraint.constant = 50
            self.musicViewTopConstraint.constant = 50
            self.speedTopConstraint.constant = 50
            self.backgrounViewTopConstraint.constant = 50
            self.view.layoutIfNeeded()
        }, completion:nil)
        basciCollectionView.reloadData()
    }
    
    
    @IBAction func musicAction(_ sender: UIButton) {
        transitionBtn.setImage(UIImage.init(named:"transition"), for: UIControlState.normal)
        musicBtn.setImage(UIImage.init(named:"music1"), for: UIControlState.normal)
        
        speedBtn.setImage(UIImage.init(named:"speed"), for: UIControlState.normal)
        backgroundBtn.setImage(UIImage.init(named:"bg"), for: UIControlState.normal)
        UIView.animate(withDuration:0.5, animations: {
            self.editViewTopConstraint.constant = 50
            self.speedTopConstraint.constant = 50
            self.musicViewTopConstraint.constant = -70
            self.backgrounViewTopConstraint.constant = 50
            self.view.layoutIfNeeded()
        }, completion:nil)
        
    }
    
    
    
    @IBAction func backgroundAction(_ sender: UIButton) {
        
        
        backgroundBtn.setImage(UIImage.init(named:"backgnd1"), for: UIControlState.normal);
        transitionBtn.setImage(UIImage.init(named:"transition"), for: UIControlState.normal)
        musicBtn.setImage(UIImage.init(named:"music"), for: UIControlState.normal)
        
        speedBtn.setImage(UIImage.init(named:"speed"), for: UIControlState.normal)
        
        UIView.animate(withDuration:0.5, animations: {
            self.editViewTopConstraint.constant = 50
            self.speedTopConstraint.constant = 50
            self.musicViewTopConstraint.constant = 50
            self.backgrounViewTopConstraint.constant = -70
            self.view.layoutIfNeeded()
        }, completion:nil)
    }
    
    
    @IBAction func speedAction(_ sender: UIButton) {
        transitionBtn.setImage(UIImage.init(named:"transition"), for: UIControlState.normal)
        musicBtn.setImage(UIImage.init(named:"music"), for: UIControlState.normal)
        
        speedBtn.setImage(UIImage.init(named:"speed1"), for: UIControlState.normal)
        backgroundBtn.setImage(UIImage.init(named:"bg"), for: UIControlState.normal)
        
        
        UIView.animate(withDuration:0.5, animations: {
            self.editViewTopConstraint.constant = 50
            self.musicViewTopConstraint.constant = 50
            self.speedTopConstraint.constant = -70
            self.view.layoutIfNeeded()
        }, completion:nil)
    }
    
    
    
    @IBAction func editAction(_ sender: UIButton) {
        UIView.animate(withDuration:0.5, animations: {
            self.speedTopConstraint.constant = 50
            self.musicViewTopConstraint.constant = 50
            self.editViewTopConstraint.constant = -70
            self.view.layoutIfNeeded()
        }, completion:nil)
    }
    
    @IBAction func playPauseAction(_ sender: UIButton) {
        if sender.isSelected || !isPlaying {
            sender.setImage(UIImage.init(named:"pause"), for:.normal)
            sender.isSelected = false;
            player.seek(to:kCMTimeZero)
            player.play()
            audioPlayer?.play()
            isPlaying = true
            
        }
        else {
            player.pause()
            audioPlayer?.pause()
            self.isPlaying = false
            sender.isSelected = true
            sender.setImage(UIImage.init(named:"play"), for:.normal)
        }
        
    }
}


extension VideoEditorController:UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if(collectionView == basciCollectionView){
            return imageTransitionArray.count
        }else if(collectionView == musicCollectionView){
            return musicLabelArray.count
        }
        else{
            if(fromBgColor){
                return bgColorArray.count
            }else if(fromBgPattern){
                return patternTransparentArray.count
            }else if(fromBgGradient){
                return gradientTransparentArray.count
            }else{
                return 10
            }
            
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if(collectionView == basciCollectionView){
            let customCell = collectionView.dequeueReusableCell(withReuseIdentifier:"customCell", for: indexPath) as! CustomCollectionViewCell
            if(fromTransition){
                customCell.basicImageView.image = UIImage.init(named: imageTransitionArray[indexPath.row])
                customCell.basicLabel.text = imageTransitionArray[indexPath.row]
            }
            
            if(selectedIndex==indexPath.row){
                 customCell.basicImageView.layer.borderWidth = 2.0
                 customCell.basicImageView.layer.borderColor = UIColor.green.cgColor;
            }else{
                 customCell.basicImageView.layer.borderWidth = 2.0
                 customCell.basicImageView.layer.borderColor = UIColor.clear.cgColor;
            }
            
            return customCell
        }else if(collectionView == musicCollectionView){
            let musicCell = collectionView.dequeueReusableCell(withReuseIdentifier:"musicCell", for: indexPath) as! MusicCollectionViewCell
            
            if(selectedIndex==indexPath.row){
                musicCell.musicImgView.layer.borderWidth = 2.0
                musicCell.musicImgView.layer.borderColor = UIColor.green.cgColor;
            }else{
                musicCell.musicImgView.layer.borderWidth = 2.0
                musicCell.musicImgView.layer.borderColor = UIColor.black.cgColor;
            }
            musicCell.musicImgView.image = UIImage.init(named:musicThumbnailArray[indexPath.row])
            musicCell.musicImgView.layer.cornerRadius = musicCell.musicImgView.layer.borderWidth/2
            musicCell.musicImgView.clipsToBounds = true
            musicCell.musicName.text = musicLabelArray[indexPath.row]
            return musicCell
        }
        else{
            let bgCell = collectionView.dequeueReusableCell(withReuseIdentifier:"bgCustomCell", for: indexPath) as! BgCustomCell
            bgCell.bgImgView.layer.cornerRadius = bgCell.bgImgView.frame.size.width/2
            bgCell.bgImgView.clipsToBounds = true
            if(fromBgColor){
                bgCell.bgImgView.image = UIImage.init(named:bgColorArray[indexPath
                    .row])
            } else if(fromBgPattern){
                bgCell.bgImgView.image = UIImage.init(named:patternArray[indexPath
                    .row])
            }else if(fromBgGradient){
                bgCell.bgImgView.image = UIImage.init(named:gradientArray[indexPath
                    .row])
            }else if(fromBgImage){
                bgCell.bgImgView.image = UIImage.init(named:imageArray[indexPath
                    .row])
                
            }
            return bgCell
        }
        
    }
}

extension VideoEditorController:UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if(collectionView == basciCollectionView){
            return CGSize(width:80, height:80)
          
        }else if(collectionView == musicCollectionView){
            return CGSize(width:80, height:80)
            
        }
        else{
             return CGSize(width:60, height:60)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    
  
    
}


extension VideoEditorController:UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if(collectionView == basciCollectionView){
            if(fromTransition){
                self.fromSave = false
                self.fromPlayVideo = true
                self.playPauseBtn.isHidden = true
                self.playerLayer.removeFromSuperlayer()
                
                DispatchQueue.main.async {
                    MBProgressHUD.showAdded(to:self.view
                        , animated: true)
                }
                globalSelectedTransitionTag = indexPath.row
                exportVideoWithAnimation()
                selectedIndex = indexPath.row
                basciCollectionView.reloadData()
                
            }
        }else if(collectionView == musicCollectionView){
            self.playerLayer.removeFromSuperlayer()
            
            player.seek(to: kCMTimeZero)
            player.pause()
            self.isPlaying = false
            playPauseBtn.setImage(UIImage.init(named:"play"), for: .normal)
            self.playPauseBtn.isHidden = true
            self.musicAdded(indexPath:indexPath)
            selectedIndex = indexPath.row
            musicCollectionView.reloadData()
            
        }
        else{
            if(fromBgColor){
                self.backgroundImageView.contentMode = .scaleAspectFill
                self.backgroundImageView.isHidden = false; self.backgroundImageView.image=UIImage.init(named:bgTransparentColorArray[indexPath.row])
                globalBackgroundImage = UIImage.init(named:bgTransparentColorArray[indexPath.row])!
                
            }else if(fromBgPattern){
                self.backgroundImageView.contentMode = .scaleAspectFill
                self.backgroundImageView.isHidden = false; self.backgroundImageView.image=UIImage.init(named:patternTransparentArray[indexPath.row])
                globalBackgroundImage = UIImage.init(named:patternTransparentArray[indexPath.row])!
                
                
            }else if(fromBgGradient){
                self.backgroundImageView.contentMode = .scaleAspectFill
                self.backgroundImageView.isHidden = false; self.backgroundImageView.image=UIImage.init(named:gradientTransparentArray[indexPath.row])
                globalBackgroundImage = UIImage.init(named:gradientTransparentArray[indexPath.row])!
                
            }else if(fromBgImage){
                self.backgroundImageView.contentMode = .scaleAspectFill
                self.backgroundImageView.isHidden = false; self.backgroundImageView.image=UIImage.init(named:imageTransparentArray[indexPath.row])
                globalBackgroundImage = UIImage.init(named:imageTransparentArray[indexPath.row])!
                
            }
            
        }
    }
    
    
    
    func musicAdded(indexPath:IndexPath){
        backgroundView.backgroundColor = UIColor.clear
        fromMusic = true
        
        self.audioPlayer = nil
        
        self.playVideoInPlayer(animatedVideoURL:self.globalVideoURL as URL, rowIndexPath: indexPath.row)
        
    }
    
    func playAudio(url:URL){
        let url = url
        do {
            try audioPlayer = AVAudioPlayer(contentsOf: url)
            audioPlayer?.delegate = self as? AVAudioPlayerDelegate
            audioPlayer?.prepareToPlay()
            audioPlayer?.play()
            
        } catch let error as NSError {
            print("audioPlayer error \(error.localizedDescription)")
        }
    }
    
    
    
}




extension VideoEditorController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
